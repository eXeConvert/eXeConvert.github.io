/*!
 * eXeLearning v4.0.0 Universal Style Script File
 * -----------------------
 * Author: Ignacio Gros
 * Project: eXeLearning.net
 *
 * This JavaScript file is part of a style for eXeLearning.
 * Licensed under Creative Commons Attribution-ShareAlike (CC BY-SA).
 *
 * Note: The style's config.xml contains additional information
 *       about materials (images, fonts, etc.) created by third parties
 *       and included in this style.
 */

var eXeUniversalStyle = {
    breadcrumbs : true,
    dropdownNavigation : true,
    darkModeWebSiteOnly : true,
    init: function () {
        // Common functions
        var togglers = '';
        if (this.isLocalStorageAvailable()) {
            togglers =
                '\
                <button type="button" id="darkModeToggler" class="toggler" title="' +
                $exe_i18n.mode_toggler +
                '">\
                    <span>' +
                $exe_i18n.mode_toggler +
                '</span>\
                </button>\
            ';
        }
        if (!$('body').hasClass('exe-web-site')) {
            // The stored choice is restored at parse time, before the format is known
            if (this.darkModeWebSiteOnly) {
                $('html').removeClass('exe-dark-mode');
                return;
            }
            $('.package-header').prepend(togglers);
            // Dark mode
            eXeUniversalStyle.darkMode.init();
            return;
        }
        // Add menu and search bar togglers
        togglers +=
            '\
            <button type="button" id="siteNavToggler" class="toggler" aria-expanded="true" aria-controls="siteNav" title="' +
            $exe_i18n.menu +
            '">\
                <span>' +
            $exe_i18n.menu +
            '</span>\
            </button>\
        ';
        // The search box is optional: only add its toggler when it exists
        if ($('#exe-client-search').length) {
            togglers +=
                '\
                <button type="button" id="searchBarToggler" class="toggler" aria-expanded="false" aria-controls="exe-client-search" title="' +
                $exe_i18n.search +
                '">\
                    <span>' +
                $exe_i18n.search +
                '</span>\
                </button>\
            ';
        }
        $('#siteNav').before(togglers);
        // Check the current NAV status
        if (new URLSearchParams(window.location.search).get('nav') == 'false') {
            $('body').addClass('siteNav-off');
            eXeUniversalStyle.navExpanded(false);
            eXeUniversalStyle.params('add');
        }
        // Dark mode
        this.darkMode.init();
        // Menu toggler
        $('#siteNavToggler').on('click', function () {
            if (eXeUniversalStyle.isLowRes()) {
                $('#exe-client-search').hide();
                $('#searchBarToggler').attr('aria-expanded', 'false');
                if ($('body').hasClass('siteNav-off')) {
                    $('body').removeClass('siteNav-off');
                } else {
                    if ($('#siteNav').isInViewport()) {
                        $('body').addClass('siteNav-off');
                        eXeUniversalStyle.params('add');
                    }
                }
                window.scroll(0, 0);
            } else {
                $('body').toggleClass('siteNav-off');
                eXeUniversalStyle.params(
                    $('body').hasClass('siteNav-off') ? 'add' : 'remove'
                );
            }
            eXeUniversalStyle.navExpanded(!$('body').hasClass('siteNav-off'));
        });
        // Search bar toggler
        $('#searchBarToggler').on('click', function () {
            var bar = $('#exe-client-search');
            if (bar.is(':visible')) {
                bar.hide();
            } else {
                if (eXeUniversalStyle.isLowRes()) {
                    $('body').addClass('siteNav-off');
                    eXeUniversalStyle.navExpanded(false);
                }
                bar.show();
                $('#exe-client-search-text').focus();
                window.scroll(0, 0);
            }
            $(this).attr('aria-expanded', bar.is(':visible'));
        });
        // Allways close the menu in low resolution
        $('#siteNav a').on('click', function(event){
            if (event.target.nodeName == 'A') {
                if (eXeUniversalStyle.isLowRes()) {
                    event.preventDefault();
                    window.location = $exeExport.setUrlParam(this.href, 'nav', 'false');
                }
            }
        });
        // Breadcrumbs
        this.getBreadcrumbs();
        // Enable dropdowns in the main navigation menu
        this.dropdownMenus();
        // Search form
        this.searchForm();
    },
    isLocalStorageAvailable : function(){
        var x = '';
        try {
            localStorage.setItem(x, x);
            localStorage.removeItem(x);
            return true;
        } catch(e) {
            return false;
        }
    },
    darkMode : {
        init : function(){
            $('#darkModeToggler').attr('aria-pressed', $('html').hasClass('exe-dark-mode') ? 'true' : 'false');
            $('#darkModeToggler').on('click', function(){
                var active = 'off';
                if (!$('html').hasClass('exe-dark-mode')) active = 'on';
                eXeUniversalStyle.darkMode.setMode(active);
                $(this).attr('aria-pressed', active == 'on' ? 'true' : 'false');
            });
        },
        stored : function(){
            try {
                return localStorage.getItem('exeDarkMode');
            } catch(e) {
                return null;
            }
        },
        store : function(value){
            try {
                if (value) {
                    localStorage.setItem('exeDarkMode', value);
                } else {
                    localStorage.removeItem('exeDarkMode');
                }
            } catch(e) {}
        },
        setMode : function(active){
            var dark = false;
            var darkMode = this.stored();
            if (darkMode && darkMode == 'on') {
                dark = true;
            }
            if (active) {
                if (active == 'off') {
                    dark = false;
                } else {
                    dark = true;
                }
            }
            if (dark) {
                this.store('on');
                $('html').addClass('exe-dark-mode');
            } else {
                this.store('');
                $('html').removeClass('exe-dark-mode');
            }
        }
    },
    searchForm: function () {
        $('#exe-client-search-text').attr('class', 'form-control');
    },
    isLowRes: function () {
        return $('#siteNav').css('position') == 'static';
    },
    truncate : function(str) {
        var max = 25;
        if (str.length > max) {
            return str.substring(0, max - 3) + '...';
        }
        return str;
    },
    removeQuotes : function(str){
        return str.replace(/"/g, '');
    },
    getBreadcrumbs : function(){
        if(!this.breadcrumbs) return;
        if ($("html").attr("id")=="exe-index") return false;
        // Page titles are text: build nodes, never markup
        function link(a){
            var text = a.text();
            return $("<a></a>").attr("href",a.attr("href")).attr("title",text).data("src",a[0]).append($("<span></span>").text(eXeUniversalStyle.truncate(text)));
        }
        function getNodeLinks(){
            var res = $("<li></li>").append($("<strong></strong>").append($("<span></span>").text(eXeUniversalStyle.truncate($(".page-header .page-title").text()))));
            var extra = [];
            var loc = window.location.href;
                loc = loc.split("/");
                loc = loc[loc.length-1];
                loc = loc.split("?");
                loc = loc[0];
                loc = loc.split("#");
                loc = loc[0];
            var mainTit = "";
            var mainLnk = "";
            var mainSrc = null;
            $("#siteNav a").each(function(x){
                var e = $(this);
                if (x==0) {
                    mainTit = e.text();
                    mainLnk = e.attr("href");
                    mainSrc = this;
                }
                var ref = e.attr("href");
                if (ref==loc || ref.endsWith("/" + loc)) {
                    var li = e.parent();
                    li.parents('li').each(function() {
                        var a = $("a",this).eq(0);
                        extra.unshift($("<li></li>").append(link(a)));
                    });
                }
            });
            if ($('html').attr('id')=='exe-index') {
                extra = [];
                res = [];
            }
            var img = 'theme/img/home.png';
            if ($('html').attr('id')!='exe-index') img = '../' + img;
            var home = $('<a id="siteBreadcrumbsHome"></a>').attr("href",mainLnk).attr("title",mainTit).data("src",mainSrc);
            home.append($('<img width="19" height="19">').attr("src",img).attr("alt",mainTit));
            home.append($('<span class="sr-av"></span>').text(mainTit));
            return [$("<li></li>").append(home)].concat(extra,res);
        }
        var breadcrumb = $('<div id="siteBreadcrumbs"><ul></ul></div>');
        breadcrumb.find("ul").append(getNodeLinks());
        $(".package-header").prepend(breadcrumb).addClass("width-breadcrumbs");
        // Hrefs read at click time: mode params (exe-teacher, exe-presentation) are added to the menu after init
        breadcrumb.on("mousedown click", "a", function(){
            var src = $(this).data("src");
            if (src) this.setAttribute("href", src.getAttribute("href"));
        });
    },
    dropdownMenus: function(){
        if (!this.dropdownNavigation) {
            $('#siteNav .other-section').show();
            return;
        }
        this.dropdownMenusWorking = false;
        $('#siteNav ul ul').each(function(i){
            var elem = $(this);
            this.id = 'child-section-'+i;
            var lnk = elem.prev('a');
            var open = elem.is(':visible');
            var css = open ? 'open-ul' : 'closed-ul';
            lnk.append('<button id="child-section-'+i+'-toggler" title="'+$exe_i18n.more+'" class="'+css+'" aria-expanded="'+open+'" aria-controls="child-section-'+i+'"><span>'+$exe_i18n.more+'</span></button>');
            $('#child-section-'+i+'-toggler').on('click', function(event){
                event.preventDefault();
                if (eXeUniversalStyle.dropdownMenusWorking == true) return;
                eXeUniversalStyle.dropdownMenusWorking = true;
                var id = this.id;
                    id = id.replace('-toggler', '');
                var ul = $('#'+id);
                if (ul.is(':visible')) {
                    ul.slideUp('fast', function(){
                        var lnk = $('#'+this.id+'-toggler');
                            lnk.removeClass('open-ul');
                            lnk.addClass('closed-ul');
                            lnk.attr('aria-expanded', 'false');
                        eXeUniversalStyle.dropdownMenusWorking = false;
                    });
                } else {
                    ul.slideDown('fast', function(){
                        var lnk = $('#'+this.id+'-toggler');
                            lnk.removeClass('closed-ul');
                            lnk.addClass('open-ul');
                            lnk.attr('aria-expanded', 'true');
                        eXeUniversalStyle.dropdownMenusWorking = false;
                    });
                }
            });
        })
    },
    navExpanded: function (visible) {
        $('#siteNavToggler').attr('aria-expanded', visible ? 'true' : 'false');
        $('#siteNav').prop('inert', !visible);
    },
    // Toggle nav=false keeping the rest of the URL using a common function.
    params: function (act) {
        var value = act == 'add' ? 'false' : null;
        $('.nav-buttons a').each(function () {
            this.setAttribute(
                'href',
                $exeExport.setUrlParam(this.getAttribute('href'), 'nav', value)
            );
        });
    },
};
$(function () {
    eXeUniversalStyle.init();
});
eXeUniversalStyle.darkMode.setMode();
$.fn.isInViewport = function () {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight();
    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();
    return elementBottom > viewportTop && elementTop < viewportBottom;
};
